#include "csaladi.hpp"

void Csaladi::kiir(std::ostream& os)
{
    os << cim << " / " << hossz/3600 << ":" << hossz/60%60 << ":" << hossz%60
    << " / " << ev <<" / " << korhatar << std::endl;
}
void Csaladi::fkiir(std::ostream& os)
{
    os << this->tipus() << '/' << cim << '/' << hossz << '/' << ev << '/' << korhatar <<std::endl;
}
Csaladi& Csaladi::operator=(const Csaladi& rhs)
{
    if(this != &rhs)
    {
        cim = rhs.cim;
        hossz = rhs.hossz;
        ev = rhs.ev;
        korhatar = rhs.korhatar;
    }
    return *this;
}

bool Csaladi::keres(const string& data)
{
    bool vane = Film::keres(data);
    if(std::to_string(this->getKorhatar()).find(data) != std::string::npos)
    {
        vane = true;
    }
    return vane;
}
