#include "dokumentum.hpp"

void Dokumentum::kiir(std::ostream& os)
{
    os << cim << " / " << hossz/3600 << ":" << hossz/60%60 << ":" << hossz%60
    << " / " << ev <<" / " << leiras << std::endl;
}
void Dokumentum::fkiir(std::ostream& os)
{
    os << this->tipus() << '/' << cim << '/' << hossz << '/' << ev << '/' << leiras <<std::endl;
}
Dokumentum& Dokumentum::operator=(const Dokumentum& rhs)
{
    if(this != &rhs)
    {
        cim = rhs.cim;
        hossz = rhs.hossz;
        ev = rhs.ev;
        leiras = rhs.leiras;
    }
    return *this;
}

bool Dokumentum::keres(const string& data)
{
    bool vane = Film::keres(data);
    if(this->getLeiras().find(data) != std::string::npos)
    {
        vane = true;
    }
    return vane;
}
