#ifndef DOKUMENTUM_HPP_INCLUDED
#define DOKUMENTUM_HPP_INCLUDED

#include "film.hpp"
#include <iostream>

using namespace std;

class Dokumentum: public Film
{
    string leiras;
public:
    Dokumentum(string cim = "", int hossz = 0, int ev = 0, string leiras = ""): Film(cim, hossz, ev), leiras(leiras) {}
    ~Dokumentum(){}
    string getLeiras() {return leiras;}
    void setLeiras(string leiras) {this->leiras = leiras;}
    void kiir(std::ostream& os);
    char tipus(){ return 'D'; }
    void fkiir(std::ostream& os);
    Dokumentum& operator=(const Dokumentum&);
    bool keres(const string&);
};

#endif // DOKUMENTUM_HPP_INCLUDED
