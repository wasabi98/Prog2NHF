#include "eletrajz.hpp"

void Eletrajz::kiir(std::ostream& os)
{
    os << cim << " / " << hossz/3600 << ":" << hossz/60%60 << ":" << hossz%60
    << " / " << ev <<" / " << karakter << std::endl;
}
void Eletrajz::fkiir(std::ostream& os)
{
    os << this->tipus() << '/' << cim << '/' << hossz << '/' << ev << '/' << karakter <<std::endl;
}
Eletrajz& Eletrajz::operator=(const Eletrajz& rhs)
{
    if(this != &rhs)
    {
        cim = rhs.cim;
        hossz = rhs.hossz;
        ev = rhs.ev;
        karakter = rhs.karakter;
    }
    return *this;
}

bool Eletrajz::keres(const string& data)
{
    bool vane = Film::keres(data);
    if(this->getKarakter().find(data) != std::string::npos)
    {
        vane = true;
    }
    return vane;
}
