#ifndef ELETRAJZ_HPP_INCLUDED
#define ELETRAJZ_HPP_INCLUDED

#include "film.hpp"
#include <iostream>

using namespace std;

class Eletrajz: public Film
{
    string karakter;
public:
    Eletrajz(string cim= "", int hossz = 0, int ev = 0, string karakter= ""): Film(cim, hossz, ev), karakter(karakter) {}
    ~Eletrajz(){}
    string getKarakter() {return karakter;}
    void setKarakter(string karakter) {this->karakter = karakter;}
    void kiir(std::ostream& os);
    char tipus(){ return 'E'; }
    void fkiir(std::ostream& os);
    Eletrajz& operator=(const Eletrajz&);
    bool keres(const string&);
};

#endif // ELETRAJZ_HPP_INCLUDED
