#ifndef FAJL_H_INCLUDED
#define FAJL_H_INCLUDED

#include <iostream>
#include <fstream>
#include <string>
#include "tarolo.hpp"
#include "csaladi.hpp"
#include "dokumentum.hpp"
#include "eletrajz.hpp"

using namespace std;


string* Fsplit(string s, char c)
{
    int meret = 0;
    if(s[0] == 'F'){ meret = 4; }
    else{ meret = 5; }

    string* tomb = new string[meret];
    int db = 0;

    size_t pos = 0;
    std::string temp;
    while ((pos = s.find(c)) != std::string::npos)
    {
        temp = s.substr(0, pos);
        tomb[db++] = temp;
        s.erase(0, pos + 1);

    }
    tomb[db] = s;
    return tomb;
}

void betolt(Tarolo& tarolo)
{
    string sor;
    ifstream fajl("fajl.txt");
    if (fajl.is_open())
    {
        while (getline(fajl,sor))
        {
            string* split = Fsplit(sor, '/');
            switch(sor[0])
            {
            case 'F':
                {
                    Film *film = new Film(split[1], std::stoi (split[2]),std::stoi (split[3]));
                    tarolo.felvesz(film);
                    break;
                }

            case 'D':
                {
                    Dokumentum *dokumentum = new Dokumentum(split[1],std::stoi (split[2]),std::stoi (split[3]),split[4]);
                    tarolo.felvesz(dokumentum);
                    break;
                }

            case 'C':
                {
                    Csaladi *csaladi = new Csaladi(split[1],std::stoi (split[2]),std::stoi (split[3]),std::stoi (split[4]));
                    tarolo.felvesz(csaladi);
                    break;
                }
            case 'E':
                {
                    Eletrajz *eletrajz = new Eletrajz(split[1],std::stoi (split[2]),std::stoi (split[3]),split[4]);
                    tarolo.felvesz(eletrajz);
                    break;
                }

            }
            delete[] split;
        }
        fajl.close();
    }


}
void ment(Tarolo& tarolo)
{
    ofstream fajl("fajl.txt");
    if (fajl.is_open())
    {
        for(unsigned int i = 0; i < tarolo.getDb();i++)
        {
            tarolo[i]->fkiir(fajl);
        }
        fajl.close();
    }

    fajl.close();
}

#endif // FAJL_H_INCLUDED
