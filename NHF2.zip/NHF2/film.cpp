#include "film.hpp"

void Film::kiir(std::ostream& os)
{
    os << cim << " / " << hossz/3600 << ":" << hossz/60%60 << ":" << hossz%60
    << " / " << ev << std::endl;
}

void Film::fkiir(std::ostream& os)
{
    os << this->tipus() << '/' << cim << '/' << hossz << '/' << ev << std::endl;
}

Film& Film::operator=(const Film& rhs)
{
    if(this != &rhs)
    {
        cim = rhs.cim;
        hossz = rhs.hossz;
        ev = rhs.ev;
    }
    return *this;
}

bool Film::keres(const std::string& data)
{
    bool vane = false;
    if(this->getCim().find(data) != std::string::npos)
    {
        vane = true;
    }
    if(std::to_string(this->getHossz()).find(data) != std::string::npos)
    {
        vane = true;
    }
    if(std::to_string(this->getEv()).find(data) != std::string::npos)
    {
        vane = true;
    }
    return vane;
}
