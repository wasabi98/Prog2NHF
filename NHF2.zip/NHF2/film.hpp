#ifndef FILM_HPP_INCLUDED
#define FILM_HPP_INCLUDED

#include <iostream>
using namespace std;

class Film
{
protected:
    string cim;
    int hossz; /** */
    int ev;
public:
    Film(string cim = "", int hossz = 0, int ev = 0) : cim(cim), hossz(hossz), ev(ev) {}
    virtual ~Film(){}
    string getCim() { return cim;}
    int getHossz() { return hossz; }
    int getEv() { return ev; }
    void setCim(string cim) { this->cim = cim; }
    void setHossz(int hossz) { this->hossz = hossz; }
    void setEv(int ev) { this->ev = ev; }
    virtual void kiir(std::ostream& os);
    virtual char tipus(){ return 'F'; }
    virtual void fkiir(std::ostream& os);
    virtual Film& operator=(const Film&);
    virtual bool keres(const string&);
};


#endif // FILM_HPP_INCLUDED
