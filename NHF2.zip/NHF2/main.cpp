#include "csaladi.hpp"
#include "dokumentum.hpp"
#include "eletrajz.hpp"
#include "film.hpp"
#include "tarolo.hpp"
#include "fajl.h"
#include "memtrace.h"
#include <string>


using std::cout;
using std::endl;


void filmTest()
{
    Film film1("test1", 10000, 1999);
    const char* ch = "test2";
    Film film2(ch, 12000, 2000);
    cout<< film2.tipus() << " " << film2.getCim() << " " << film2.getCim() << " "
    << film2.getHossz() << " " << film2.getEv() << endl;

    Film film3;
    film3.setCim("test3");
    film3.setHossz(13111);
    film3.setEv(1899);

    film3 = film1;
    film3.kiir(cout);
    film3 = film3;
    film3.kiir(cout);
}

void DokTest()
{
    Dokumentum dok1("Doktest1", 12000, 1867, "test1 leiras");
    const char* ch = "Doktest2";
    Dokumentum dok2(ch, 11000, 1998, "test2 leiras");
    Dokumentum dok3;
    dok3 = dok2;
    dok3.setLeiras("test3 leiras");
    cout << dok3.tipus() << " " << dok3.getLeiras() << endl;
    dok1 = dok1;
    dok1.kiir(cout);
}

void EletTest()
{
    Eletrajz elet1("Elettest1", 12000, 1867, "Albert");
    const char* ch = "Elettest2";
    Eletrajz elet2(ch, 11000, 1998, "Ferenc");
    Eletrajz elet3;
    elet3 = elet2;
    elet3.setKarakter("Csongor");
    cout << elet3.tipus() << " " << elet3.getKarakter() << endl;
    elet1 = elet1;
    elet1.kiir(cout);
}
void CsalTest()
{
    Csaladi csal1("csaltest1", 12000, 1867, 12);
    const char* ch = "csaltest2";
    Csaladi csal2(ch, 11000, 1998, 16);
    Csaladi csal3;
    csal3 = csal2;
    csal3.setKorhatar(18);
    cout << csal3.tipus() << " " << csal3.getKorhatar() << endl;
    csal1 = csal1;
    csal1.kiir(cout);
}
void TaroloTest()
{
    Tarolo tarolo1;

    Film *film = new Film("teszt", 34513, 1667);
    Dokumentum *dok = new Dokumentum("DokTeszt", 45222, 1988, "leleleleiras");
    Eletrajz *elet = new Eletrajz("EletTeszt", 29866, 1867, "Kaposztas Bob");
    Csaladi *csal = new Csaladi("CSaladTeszt", 17554, 1945, 6);

    tarolo1.felvesz(film);
    tarolo1.felvesz(dok);
    tarolo1.felvesz(elet);
    tarolo1.felvesz(csal);

    tarolo1.torol();

}
void fajlTest()
{
    Tarolo tarolo;

    Film *film = new Film("teszt", 34513, 1667);
    Dokumentum *dok = new Dokumentum("DokTeszt", 45222, 1988, "leleleleiras");
    Eletrajz *elet = new Eletrajz("EletTeszt", 29866, 1867, "Kaposztas Bob");
    Csaladi *csal = new Csaladi("CSaladTeszt", 17554, 1945, 6);

    tarolo.felvesz(film);
    tarolo.felvesz(dok);
    tarolo.felvesz(elet);
    tarolo.felvesz(csal);

    ment(tarolo);
    tarolo.~Tarolo();

    Tarolo tarolo2;
    betolt(tarolo2);

    Tarolo tarolo3;
    tarolo3 = tarolo2;

    for(int i = 0; i< 51;i++)
    {
        Film *film = new Film("teszt", 34513, 1667);
        tarolo3.felvesz(film);
    }


    string* s = Fsplit("test/teszt", '/');
    cout << s[0] << s[1];
    delete[] s;

}



int main()
{
    /*filmTest();
    DokTest();
    EletTest();
    CsalTest();
    TaroloTest();
    fajlTest();*/

    char input;
    string inputS;
    Tarolo tarolo;
    while(toupper(input) != 'X')
    {
        cout << "\n[F] film felvetele\n"
             << "[K] film keresese\n"
             << "[T] film torlese\n"
             << "[M] filmek mentese\n"
             << "[B] filmek betoltese\n"
             << "[L] filmek kilistazasa\n"
             << "[X] kilepes\n";
        std::getline(cin, inputS);
        if(inputS.length() > 1)
            input = 'Z';
        else
            input = inputS[0];

        cout << endl;
        switch(toupper(input))
        {
            case 'F':
            {
                cout << "Milyen tipusu a film?" << endl
                <<      "(sima) [F]ilm, [D]okumentum film, [C]saladi film, [E]letrajz" << endl;
                string tipus;
                std::getline(cin, tipus);
                if(tipus.length() > 1)
                {
                    cout << "ez nem karakter ;_;";
                    break;

                }

                string cim, egyeb, hossz, ev;

                cout << "Film cime:" << endl;
                std::getline(cin, cim);
                cout << endl << "Film hossza (masodpercben):" << endl;
                std::getline(cin, hossz);
                cout << endl << "Film kiadasanak eve:" << endl;
                std::getline(cin, ev);
                try
                {
                    switch(tipus[0])
                    {

                        case 'f':
                        case 'F':
                        {
                            tarolo.felvesz(new Film(cim, std::stoi(hossz), std::stoi(ev)));
                            break;
                        }
                        case 'd':
                        case 'D':
                        {

                            cout << endl << "Film rovid leirasa:" << endl;
                            std::getline(cin, egyeb);
                            tarolo.felvesz(new Dokumentum(cim, std::stoi(hossz), std::stoi(ev), egyeb));
                            break;
                        }
                        case 'c':
                        case 'C':
                        {
                            cout << endl << "Film korhatara:" << endl;
                            std::getline(cin, egyeb);
                            tarolo.felvesz(new Csaladi(cim, std::stoi(hossz), std::stoi(ev), std::stoi(egyeb)));
                            break;
                        }
                        case 'e':
                        case 'E':
                        {

                            cout << endl << "A feldolgozott karakter neve:" << endl;
                           std::getline(cin, egyeb);
                            tarolo.felvesz(new Eletrajz(cim, std::stoi(hossz), std::stoi(ev), egyeb));
                            break;
                        }
                        default:
                        {
                            cout << endl << "nincs ilyen tipusu film";
                            break;
                        }
                    }
                }
                catch(std::invalid_argument)
                {
                    cout << "hat bizony ez nem egy szam";
                }
                break;
            }
            case 'K':
            {
                string data;
                cout << "Adja meg a kulcsszot:" << endl;
                std::getline(cin, data);
                for(unsigned int i = 0; i < tarolo.getDb();i++)
                    if(tarolo[i]->keres(data))
                    {
                        cout << endl << "[" << i+1 << "] ";
                        tarolo[i]->kiir(cout);
                    }
                break;
            }
            case 'T':
            {
                string idx;
                cout << "Adja meg melyik filmet szeretne torolni (sorszam)" << endl;
                std::getline(cin, idx);
                try
                {
                    tarolo.elemTorol(std::stoi(idx)-1);
                    cout << endl << "Sikerult!";
                }
                catch(std::invalid_argument)
                {
                    cout << "Ez nem jo sorszam";
                }
                catch(std::out_of_range)
                {
                    cout << "Kimentel a filmek hatarain, gratulalok.";
                }

                break;
            }
            case 'M':
            {
                ment(tarolo);
                cout << "Elmentve";
                break;
            }
            case 'B':
            {
                tarolo.kiurit();
                betolt(tarolo);
                cout << "Betoltve";
                break;
            }
            case 'L':
            {
                for(unsigned int i = 0; i < tarolo.getDb(); i++)
                {
                    cout << "[" << i+1 << "] ";
                    tarolo[i]->kiir(cout);
                    cout << endl;
                }
                break;
            }
            case 'X':
            {
                cout << "Viszlat!";
                break;
            }
            case 'Z':
            {
                cout << "Ez nem egy karakter";
                break;
            }
            default:
            {
                cout << "Nincs ilyen menupont";
                break;
            }
        }

    }






    return 0;
}
