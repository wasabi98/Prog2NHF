#ifndef MYSTRING_HPP_INCLUDED
#define MYSTRING_HPP_INCLUDED

#include <iostream>
#include <cstring>

class String {
    private:
        size_t hossz;
        char* adat;

    public:
        String(char const *szoveg = "") {
            hossz = strlen(szoveg);
            adat = new char[hossz+1];
            strcpy(adat, szoveg);
        }


        ~String() {
            delete[] adat;
        }


        String(String const & orig) {
            hossz = orig.hossz;
            adat = new char[hossz+1];
            strcpy(adat, orig.adat);
        }


        String& operator=(String const & orig) {
            if (this != &orig) {
                delete[] adat;
                hossz = orig.hossz;
                adat = new char[hossz+1];
                strcpy(adat, orig.adat);
            }
            return *this;
        }

        size_t size() const {
            return hossz;
        }

        char const & operator[] (size_t idx) const {
            return adat[idx];
        }

        char & operator[] (size_t idx) {
            return adat[idx];
        }


        String operator+(String const & rhs) const {
            String uj;
            delete[] uj.adat;
            uj.hossz = this->hossz + rhs.hossz;
            uj.adat = new char[uj.hossz + 1];
            strcpy(uj.adat, this->adat);
            strcat(uj.adat, rhs.adat);
            return uj;
        }
};

std::ostream& operator<<(std::ostream& os, const String& s) {
    for (size_t i = 0; i != s.size(); ++i)
        os << s[i];
    return os;
}




#endif // MYSTRING_HPP_INCLUDED
