#ifndef CSALADI_HPP_INCLUDED
#define CSALADI_HPP_INCLUDED

#include "film.hpp"
#include <cstring>
#include <iostream>
class Csaladi: public Film
{
    int korhatar;
public:
    Csaladi(string cim= "", int hossz = 0, int ev = 0, int korhatar = 0): Film(cim, hossz, ev), korhatar(korhatar) {}
    Csaladi(const char* cim= "", int hossz = 0, int ev = 0, int korhatar = 0): Film(cim, hossz, ev), korhatar(korhatar) {}
    ~Csaladi(){}
    int getKorhatar() {return korhatar;}
    void setKorhatar(int korhatar) {this->korhatar = korhatar;}
    void kiir(std::ostream& os);
    virtual Csaladi operator=(const Csaladi&);
};

#endif // CSALADI_HPP_INCLUDED
