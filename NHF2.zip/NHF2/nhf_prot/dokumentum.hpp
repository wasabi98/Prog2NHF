#ifndef DOKUMENTUM_HPP_INCLUDED
#define DOKUMENTUM_HPP_INCLUDED

#include "film.hpp"
#include <cstring>
#include <iostream>
class Dokumentum: public Film
{
    string leiras;
public:
    Dokumentum(string cim = "", int hossz = 0, int ev = 0, string leiras = ""): Film(cim, hossz, ev), leiras(leiras) {}
    Dokumentum(const char* cim = "", int hossz = 0, int ev = 0, const char* leiras = ""): Film(cim, hossz, ev), leiras(leiras) {}
    ~Dokumentum(){}
    string getLeiras() {return leiras;}
    void setLeiras(string leiras) {this->leiras = leiras;}
    void kiir(std::ostream& os);
    virtual Dokumentum operator=(const Dokumentum&);
};

#endif // DOKUMENTUM_HPP_INCLUDED
