#ifndef ELETRAJZ_HPP_INCLUDED
#define ELETRAJZ_HPP_INCLUDED

#include "film.hpp"
#include <cstring>
#include <iostream>
class Eletrajz: public Film
{
    string karakter;
public:
    Eletrajz(string cim= "", int hossz = 0, int ev = 0, string karakter= ""): Film(cim, hossz, ev), karakter(karakter) {}
    Eletrajz(const char* cim= "", int hossz = 0, int ev = 0, const char* karakter= ""): Film(cim, hossz, ev), karakter(karakter) {}
    ~Eletrajz(){}
    string getKarakter() {return karakter;}
    void setKarakter(string karakter) {this->karakter = karakter;}
    void kiir(std::ostream& os);
    virtual Eletrajz operator=(const Eletrajz&);
};

#endif // ELETRAJZ_HPP_INCLUDED
