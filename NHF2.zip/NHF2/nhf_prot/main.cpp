#include "csaladi.hpp"
#include "dokumentum.hpp"
#include "eletrajz.hpp"
#include "film.hpp"
#include "tarolo.hpp"


int main()
{
    return 0;
}
