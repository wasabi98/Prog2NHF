#ifndef TAROLO_HPP_INCLUDED
#define TAROLO_HPP_INCLUDED

#include "film.hpp"

class Tarolo  {
    int meret=50;
    Film** tabla;
    size_t db;
public:
    Tarolo(const Tarolo&);
    Tarolo() :db(0) { }
    void torol();
    void felvesz(Film *fp);
    virtual ~Tarolo() { torol(); }
    Tarolo operator=(const Tarolo&);
};
#endif // TAROLO_HPP_INCLUDED
