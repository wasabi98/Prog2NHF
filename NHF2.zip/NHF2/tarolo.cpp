#include "tarolo.hpp"
#include "film.hpp"

Tarolo::Tarolo()
{
    meret = 50;
    db = 0;
    tabla = new Film*[50];
}

Tarolo::Tarolo(const Tarolo& rhs)
{
    meret = rhs.meret;
    db = rhs.db;
    tabla = new Film*[meret];
    for(unsigned int i = 0; i < db; i++)
    {
        tabla[i] = new Film;
        *tabla[i] = *rhs.tabla[i];
    }
}
void Tarolo::kiurit()
{
    for (size_t i = 0; i < db; i++)
        delete tabla[i];
    db = 0;
}

void Tarolo::torol()
{
    for (size_t i = 0; i < db; i++)
        delete tabla[i];
    db = 0;
    meret = 0;
    delete[] tabla;
}

void Tarolo::elemTorol(const unsigned int idx)
{
    if(idx < 0 || idx >= db)
    {
        throw std::out_of_range("");
    }
     delete tabla[idx];
     for(unsigned int i = idx; i < db-1; i++)
     {
         tabla[i] = tabla[i+1];
     }
     db--;
}




Tarolo& Tarolo::operator=(const Tarolo& rhs)
{
    if(this != &rhs)
    {
        this->torol();
        meret = rhs.meret;
        db = rhs.db;
        tabla = new Film*[meret];
        for(size_t i = 0; i < db;i++)
        {
            tabla[i] = new Film;
            *tabla[i] = *rhs.tabla[i];
        }
    }
    return *this;
}

void Tarolo::felvesz(Film *fp)
{
    if (db >= static_cast<size_t>(meret))
    {
        meret += 1;
        Film** temp = new Film*[meret];
        for(unsigned int i = 0; i < db; i++)
        {
            temp[i] = tabla[i];
        }
        delete[] tabla;
        tabla = temp;

    }
    tabla[db++] = fp;
}
Film* Tarolo::operator[](size_t i)
{
    return tabla[i];
}

