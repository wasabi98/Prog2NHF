#ifndef TAROLO_HPP_INCLUDED
#define TAROLO_HPP_INCLUDED

#include "film.hpp"
#include <iostream>
#include <fstream>

class Tarolo  {
    int meret;
    Film** tabla;
    size_t db;
public:
    Tarolo();
    Tarolo(const Tarolo&);
    void kiurit();
    void torol();
    void elemTorol(const unsigned int);
    void felvesz(Film *fp);
    size_t getDb() { return db; }
    ~Tarolo() { torol(); }
    Tarolo& operator=(const Tarolo&);
    Film* operator[](size_t i);
};


#endif // TAROLO_HPP_INCLUDED
